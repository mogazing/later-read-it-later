package com.example.pocketreborn.ui.components

import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.pocketreborn.R
import com.example.pocketreborn.navigation.Screen

data class NavItem(
    val screen: Screen,
    val titleRes: Int,
    val icon: ImageVector
)

@Composable
fun BottomNavBar(
    currentRoute: String?,
    onNavigate: (Screen) -> Unit
) {
    val items = listOf(
        NavItem(Screen.Library, R.string.tab_library, Icons.Default.LibraryBooks),
        NavItem(Screen.Discovery, R.string.tab_discovery, Icons.Default.Explore),
        NavItem(Screen.Highlights, R.string.tab_highlights, Icons.Default.FormatQuote),
        NavItem(Screen.Settings, R.string.tab_settings, Icons.Default.Settings)
    )

    NavigationBar(
        modifier = Modifier.height(64.dp)
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.screen.route ||
                (currentRoute == Screen.Search.route && item.screen == Screen.Library)
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.screen) },
                icon = { Icon(imageVector = item.icon, contentDescription = stringResource(item.titleRes)) },
                label = { Text(stringResource(item.titleRes)) }
            )
        }
    }
}
