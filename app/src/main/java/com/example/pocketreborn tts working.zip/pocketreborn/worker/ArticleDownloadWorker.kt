package com.example.pocketreborn.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.pocketreborn.data.local.AppDatabase
import com.example.pocketreborn.data.repository.ArticleRepository
import com.example.pocketreborn.data.repository.SaveResult

class ArticleDownloadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val articleId = inputData.getString(KEY_ARTICLE_ID) ?: return Result.failure()

        val db = AppDatabase.getInstance(applicationContext)
        val repository = ArticleRepository(db.articleDao(), context = applicationContext)

        return when (val saveResult = repository.processQueuedArticle(articleId)) {
            is SaveResult.Queued -> Result.success()
            is SaveResult.Success -> Result.success()
            is SaveResult.ExistingDuplicate -> Result.success()
            is SaveResult.Error -> if (saveResult.isRetryable && runAttemptCount < MAX_RETRIES) {
                Result.retry()
            } else {
                if (saveResult.isRetryable) {
                    db.articleDao().updateDownloadState(
                        articleId,
                        "FAILED",
                        "Automatic retries were exhausted. ${saveResult.message}"
                    )
                }
                Result.failure()
            }
        }
    }

    companion object {
        const val KEY_ARTICLE_ID = "key_article_id"
        private const val MAX_RETRIES = 5
    }
}
