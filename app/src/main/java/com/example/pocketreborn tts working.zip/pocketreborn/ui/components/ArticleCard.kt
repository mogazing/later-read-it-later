package com.example.pocketreborn.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.pocketreborn.data.local.entity.ArticleEntity
import java.io.File

@Composable
fun ArticleCard(
    article: ArticleEntity,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleArchive: () -> Unit,
    onToggleRead: () -> Unit,
    onAssignFolder: () -> Unit,
    onDelete: () -> Unit,
    onRetry: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    // Publisher & Date
                    Text(
                        text = buildString {
                            append(article.publisher ?: "Web Article")
                            if (!article.publishedDate.isNullOrBlank()) {
                                append(" • ")
                                append(article.publishedDate)
                            }
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Title
                    Text(
                        text = article.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Featured Image
                val imageModel = article.featuredImageLocalPath?.let { File(it) } ?: article.featuredImageUrl
                if (imageModel != null) {
                    Spacer(modifier = Modifier.width(12.dp))
                    AsyncImage(
                        model = imageModel,
                        contentDescription = "Featured image",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Excerpt
            if (!article.excerpt.isNullOrBlank()) {
                Text(
                    text = article.excerpt,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Reading Progress Bar
            if (article.readingProgress in 0.05f..0.95f) {
                LinearProgressIndicator(
                    progress = { article.readingProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Bottom Bar Actions & Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Reading time
                    Text(
                        text = "${article.estimatedReadingTimeMinutes} min read",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )

                    // Download State Badge
                    DownloadStateBadge(state = article.downloadState)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (article.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (article.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    }

                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More options",
                            tint = MaterialTheme.colorScheme.outline
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        if (article.downloadState in setOf("FAILED", "RETRY_PENDING", "BOOKMARK_ONLY")) {
                            DropdownMenuItem(
                                text = { Text("Retry saving") },
                                onClick = {
                                    showMenu = false
                                    onRetry()
                                },
                                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) }
                            )
                        }

                        DropdownMenuItem(
                            text = { Text(if (article.isRead) "Mark as Unread" else "Mark as Read") },
                            onClick = {
                                showMenu = false
                                onToggleRead()
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (article.isRead) Icons.Outlined.CheckCircle else Icons.Default.CheckCircle,
                                    contentDescription = null
                                )
                            }
                        )

                        DropdownMenuItem(
                            text = { Text(if (article.isArchived) "Unarchive" else "Archive") },
                            onClick = {
                                showMenu = false
                                onToggleArchive()
                            },
                            leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null) }
                        )

                        DropdownMenuItem(
                            text = { Text("Organize Folder") },
                            onClick = {
                                showMenu = false
                                onAssignFolder()
                            },
                            leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null) }
                        )

                        DropdownMenuItem(
                            text = { Text("Delete Article") },
                            onClick = {
                                showMenu = false
                                onDelete()
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        )
                    }
                }
            }

            if (article.downloadState in setOf("FAILED", "RETRY_PENDING", "BOOKMARK_ONLY") &&
                !article.downloadError.isNullOrBlank()
            ) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = article.downloadError,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun DownloadStateBadge(state: String) {
    val (label, color) = when (state) {
        "SAVED_OFFLINE" -> "Offline" to MaterialTheme.colorScheme.primary
        "PARTIALLY_SAVED" -> "Partial" to MaterialTheme.colorScheme.tertiary
        "BOOKMARK_ONLY" -> "Bookmark" to MaterialTheme.colorScheme.secondary
        "QUEUED", "RETRY_PENDING" -> "Queued" to MaterialTheme.colorScheme.tertiary
        "FETCHING", "EXTRACTING", "DOWNLOADING_IMAGES", "RESOLVING" -> "Saving..." to MaterialTheme.colorScheme.outline
        "FAILED" -> "Needs attention" to MaterialTheme.colorScheme.error
        else -> "Queued" to MaterialTheme.colorScheme.tertiary
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}
