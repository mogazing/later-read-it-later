package com.example.pocketreborn.ui.settings

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pocketreborn.data.repository.UserPreferences
import com.example.pocketreborn.data.repository.UserPreferencesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TtsEngineInfo(
    val packageName: String,
    val label: String
)

class SettingsViewModel(
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserPreferences()
    )

    fun getAvailableTtsEngines(context: Context): List<TtsEngineInfo> {
        val engines = mutableListOf(TtsEngineInfo("", "System Default Engine"))
        try {
            var tempTts: TextToSpeech? = null
            tempTts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tempTts?.engines?.forEach { engineInfo ->
                        if (engines.none { it.packageName == engineInfo.name }) {
                            engines.add(TtsEngineInfo(engineInfo.name, engineInfo.label))
                        }
                    }
                }
            }
            tempTts.engines?.forEach { engineInfo ->
                if (engines.none { it.packageName == engineInfo.name }) {
                    engines.add(TtsEngineInfo(engineInfo.name, engineInfo.label))
                }
            }
        } catch (_: Exception) { }
        return engines
    }

    fun updateThemeMode(mode: String) {
        viewModelScope.launch { preferencesRepository.updateThemeMode(mode) }
    }

    fun updateFontSize(sizeSp: Int) {
        viewModelScope.launch { preferencesRepository.updateFontSize(sizeSp) }
    }

    fun updateTtsSpeed(speed: Float) {
        viewModelScope.launch { preferencesRepository.updateTtsSpeed(speed) }
    }

    fun updateSelectedTtsEngine(enginePackage: String) {
        viewModelScope.launch { preferencesRepository.updateSelectedTtsEngine(enginePackage) }
    }

    fun updateDownloadOnCellular(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.updateDownloadImagesOnCellular(enabled) }
    }
}
