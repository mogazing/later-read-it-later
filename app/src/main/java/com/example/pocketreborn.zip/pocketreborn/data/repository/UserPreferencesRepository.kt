package com.example.pocketreborn.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

data class UserPreferences(
    val themeMode: String = "SYSTEM", // "LIGHT", "DARK", "SYSTEM"
    val fontSizeSp: Int = 18,
    val lineSpacingMultiplier: Float = 1.4f,
    val fontFamily: String = "DEFAULT", // "DEFAULT", "SERIF", "SANS_SERIF", "MONOSPACE"
    val defaultTtsSpeed: Float = 1.0f,
    val downloadImagesOnCellular: Boolean = true,
    val maxImageDownloadCount: Int = 20
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FONT_SIZE_SP = intPreferencesKey("font_size_sp")
        val LINE_SPACING_MULTIPLIER = floatPreferencesKey("line_spacing_multiplier")
        val FONT_FAMILY = stringPreferencesKey("font_family")
        val DEFAULT_TTS_SPEED = floatPreferencesKey("default_tts_speed")
        val DOWNLOAD_IMAGES_ON_CELLULAR = booleanPreferencesKey("download_images_on_cellular")
        val MAX_IMAGE_DOWNLOAD_COUNT = intPreferencesKey("max_image_download_count")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            themeMode = prefs[Keys.THEME_MODE] ?: "SYSTEM",
            fontSizeSp = prefs[Keys.FONT_SIZE_SP] ?: 18,
            lineSpacingMultiplier = prefs[Keys.LINE_SPACING_MULTIPLIER] ?: 1.4f,
            fontFamily = prefs[Keys.FONT_FAMILY] ?: "DEFAULT",
            defaultTtsSpeed = prefs[Keys.DEFAULT_TTS_SPEED] ?: 1.0f,
            downloadImagesOnCellular = prefs[Keys.DOWNLOAD_IMAGES_ON_CELLULAR] ?: true,
            maxImageDownloadCount = prefs[Keys.MAX_IMAGE_DOWNLOAD_COUNT] ?: 20
        )
    }

    suspend fun updateThemeMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode
        }
    }

    suspend fun updateFontSize(sizeSp: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.FONT_SIZE_SP] = sizeSp
        }
    }

    suspend fun updateLineSpacing(spacing: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LINE_SPACING_MULTIPLIER] = spacing
        }
    }

    suspend fun updateFontFamily(family: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.FONT_FAMILY] = family
        }
    }

    suspend fun updateTtsSpeed(speed: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DEFAULT_TTS_SPEED] = speed
        }
    }

    suspend fun updateDownloadImagesOnCellular(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DOWNLOAD_IMAGES_ON_CELLULAR] = enabled
        }
    }

    suspend fun updateMaxImageDownloadCount(count: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MAX_IMAGE_DOWNLOAD_COUNT] = count
        }
    }
}
