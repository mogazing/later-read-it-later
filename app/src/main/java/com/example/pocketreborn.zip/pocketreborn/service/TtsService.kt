package com.example.pocketreborn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.example.pocketreborn.MainActivity
import com.example.pocketreborn.data.local.AppDatabase
import com.example.pocketreborn.data.repository.ArticleRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

data class TtsPlaybackState(
    val articleId: String? = null,
    val articleTitle: String = "",
    val publisher: String = "",
    val isPlaying: Boolean = false,
    val currentParagraphIndex: Int = 0,
    val totalParagraphs: Int = 0,
    val speed: Float = 1.0f,
    val isInitialized: Boolean = false,
    val errorMessage: String? = null
)

class TtsService : Service(), TextToSpeech.OnInitListener {

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var tts: TextToSpeech? = null
    private var mediaSession: MediaSession? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    private var paragraphs: List<String> = emptyList()
    private var currentArticleId: String? = null
    private var currentArticleTitle: String = ""
    private var currentPublisher: String = ""

    private val _playbackState = MutableStateFlow(TtsPlaybackState())
    val playbackState: StateFlow<TtsPlaybackState> = _playbackState.asStateFlow()

    private lateinit var repository: ArticleRepository

    inner class LocalBinder : Binder() {
        fun getService(): TtsService = this@TtsService
    }

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(applicationContext)
        repository = ArticleRepository(db.articleDao(), context = applicationContext)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createNotificationChannel()

        mediaSession = MediaSession(this, "TtsServiceMediaSession").apply {
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            isActive = true
        }

        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                _playbackState.value = _playbackState.value.copy(
                    isInitialized = false,
                    errorMessage = "Language missing or unsupported for offline speech."
                )
            } else {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _playbackState.value = _playbackState.value.copy(isPlaying = true)
                        updateMediaState(PlaybackState.STATE_PLAYING)
                        updateNotification()
                    }

                    override fun onDone(utteranceId: String?) {
                        scope.launch {
                            val nextIndex = _playbackState.value.currentParagraphIndex + 1
                            if (nextIndex < paragraphs.size) {
                                _playbackState.value = _playbackState.value.copy(currentParagraphIndex = nextIndex)
                                currentArticleId?.let { id ->
                                    repository.updateTtsPosition(id, 0L, nextIndex)
                                }
                                playParagraph(nextIndex)
                            } else {
                                stopPlayback()
                            }
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        _playbackState.value = _playbackState.value.copy(
                            isPlaying = false,
                            errorMessage = "Speech synthesis error occurred."
                        )
                        updateMediaState(PlaybackState.STATE_ERROR)
                        updateNotification()
                    }
                })

                _playbackState.value = _playbackState.value.copy(isInitialized = true)
            }
        } else {
            _playbackState.value = _playbackState.value.copy(
                isInitialized = false,
                errorMessage = "Failed to initialize TextToSpeech engine."
            )
        }
    }

    fun playArticle(
        articleId: String,
        title: String,
        publisher: String,
        plainText: String,
        startParagraphIndex: Int = 0,
        speed: Float = 1.0f
    ) {
        if (plainText.isBlank()) return

        currentArticleId = articleId
        currentArticleTitle = title
        currentPublisher = publisher

        paragraphs = plainText.split(Regex("\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val initialIndex = startParagraphIndex.coerceIn(0, maxOf(0, paragraphs.size - 1))

        _playbackState.value = _playbackState.value.copy(
            articleId = articleId,
            articleTitle = title,
            publisher = publisher,
            currentParagraphIndex = initialIndex,
            totalParagraphs = paragraphs.size,
            speed = speed,
            isPlaying = true
        )

        tts?.setSpeechRate(speed)
        requestAudioFocus()
        startForeground(NOTIFICATION_ID, buildNotification())
        playParagraph(initialIndex)
    }

    private fun playParagraph(index: Int) {
        if (index !in paragraphs.indices) return
        val text = paragraphs[index]
        val utteranceId = "utterance_${currentArticleId}_$index"

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun pausePlayback() {
        tts?.stop()
        _playbackState.value = _playbackState.value.copy(isPlaying = false)
        updateMediaState(PlaybackState.STATE_PAUSED)
        updateNotification()
    }

    fun resumePlayback() {
        if (paragraphs.isNotEmpty()) {
            _playbackState.value = _playbackState.value.copy(isPlaying = true)
            requestAudioFocus()
            playParagraph(_playbackState.value.currentParagraphIndex)
        }
    }

    fun skipForward() {
        val nextIndex = (_playbackState.value.currentParagraphIndex + 1).coerceAtMost(paragraphs.size - 1)
        _playbackState.value = _playbackState.value.copy(currentParagraphIndex = nextIndex)
        if (_playbackState.value.isPlaying) {
            playParagraph(nextIndex)
        }
    }

    fun skipBackward() {
        val prevIndex = (_playbackState.value.currentParagraphIndex - 1).coerceAtLeast(0)
        _playbackState.value = _playbackState.value.copy(currentParagraphIndex = prevIndex)
        if (_playbackState.value.isPlaying) {
            playParagraph(prevIndex)
        }
    }

    fun setSpeed(speed: Float) {
        _playbackState.value = _playbackState.value.copy(speed = speed)
        tts?.setSpeechRate(speed)
    }

    fun stopPlayback() {
        tts?.stop()
        abandonAudioFocus()
        _playbackState.value = _playbackState.value.copy(isPlaying = false)
        updateMediaState(PlaybackState.STATE_STOPPED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateMediaState(state: Int) {
        val pbState = PlaybackState.Builder()
            .setActions(
                PlaybackState.ACTION_PLAY or
                        PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or
                        PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                        PlaybackState.ACTION_STOP
            )
            .setState(state, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1.0f)
            .build()
        mediaSession?.setPlaybackState(pbState)
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attr = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attr)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener { focusChange ->
                    when (focusChange) {
                        AudioManager.AUDIOFOCUS_LOSS -> pausePlayback()
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pausePlayback()
                        AudioManager.AUDIOFOCUS_GAIN -> resumePlayback()
                    }
                }
                .build()
            focusRequest?.let { audioManager?.requestAudioFocus(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager?.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager?.abandonAudioFocus(null)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Text to Speech Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controls for background speech synthesis"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val state = _playbackState.value

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(state.articleTitle.ifBlank { "Article Audio" })
            .setContentText(state.publisher.ifBlank { "Later App" })
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingIntent)
            .setOngoing(state.isPlaying)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        abandonAudioFocus()
        mediaSession?.release()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "later_tts_channel"
        const val NOTIFICATION_ID = 1001
    }
}
