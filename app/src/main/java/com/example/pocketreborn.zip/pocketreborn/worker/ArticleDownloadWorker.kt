package com.example.pocketreborn.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.pocketreborn.data.local.AppDatabase
import com.example.pocketreborn.data.repository.ArticleRepository
import com.example.pocketreborn.data.repository.SaveResult

class ArticleDownloadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val url = inputData.getString(KEY_URL) ?: return Result.failure()

        val db = AppDatabase.getInstance(applicationContext)
        val repository = ArticleRepository(db.articleDao(), context = applicationContext)

        return when (val saveResult = repository.saveArticleFromUrl(url)) {
            is SaveResult.Success -> Result.success()
            is SaveResult.ExistingDuplicate -> Result.success()
            is SaveResult.Error -> {
                if (runAttemptCount < 3) Result.retry() else Result.failure()
            }
        }
    }

    companion object {
        const val KEY_URL = "key_url"
    }
}
