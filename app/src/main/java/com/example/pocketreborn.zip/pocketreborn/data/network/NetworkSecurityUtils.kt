package com.example.pocketreborn.data.network

import java.net.InetAddress
import java.net.URL

object NetworkSecurityUtils {

    fun isSafeUrl(urlString: String): Boolean {
        return try {
            val url = URL(urlString)
            val scheme = url.protocol.lowercase()
            if (scheme != "http" && scheme != "https") {
                return false
            }

            val host = url.host
            if (host.isBlank() || host.equals("localhost", ignoreCase = true)) {
                return false
            }

            // Perform DNS check to ensure host is not a loopback / private IP destination
            val addresses = InetAddress.getAllByName(host)
            for (addr in addresses) {
                if (isPrivateAddress(addr)) {
                    return false
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun isPrivateAddress(address: InetAddress): Boolean {
        if (address.isLoopbackAddress || address.isAnyLocalAddress || address.isLinkLocalAddress || address.isSiteLocalAddress) {
            return true
        }
        val bytes = address.address
        if (bytes.size == 4) {
            val ip1 = bytes[0].toInt() and 0xFF
            val ip2 = bytes[1].toInt() and 0xFF
            // 10.0.0.0/8
            if (ip1 == 10) return true
            // 172.16.0.0/12
            if (ip1 == 172 && ip2 in 16..31) return true
            // 192.168.0.0/16
            if (ip1 == 192 && ip2 == 168) return true
            // 169.254.0.0/16
            if (ip1 == 169 && ip2 == 254) return true
            // 0.0.0.0
            if (ip1 == 0) return true
        }
        return false
    }

    fun extractUrlFromSharedText(text: String): String? {
        if (text.isBlank()) return null
        val urlRegex = Regex("""https?://[^\s<>"'{}|\\^`]+""")
        val match = urlRegex.find(text) ?: return null
        var url = match.value.trim()
        // Trim trailing punctuation like '.' or ')' or ','
        url = url.trimEnd('.', ',', ')', ']', '}', '!', '?')
        return if (isSafeUrl(url)) url else null
    }

    fun normalizeUrl(url: String): String {
        return try {
            val uri = URL(url)
            // Strip fragment (#...)
            val clean = URL(uri.protocol, uri.host, uri.port, uri.file).toString()
            clean
        } catch (e: Exception) {
            url.trim()
        }
    }
}
