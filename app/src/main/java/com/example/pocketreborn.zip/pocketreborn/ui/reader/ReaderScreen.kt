package com.example.pocketreborn.ui.reader

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    articleId: String,
    viewModel: ReaderViewModel,
    onBack: () -> Unit,
    onStartTts: (articleId: String, title: String, publisher: String, text: String) -> Unit
) {
    LaunchedEffect(articleId) {
        viewModel.loadArticle(articleId)
    }

    val state by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()
    var showFontMenu by remember { mutableStateOf(false) }

    val article = state.article

    // Track scroll position
    LaunchedEffect(scrollState.value) {
        if (scrollState.maxValue > 0) {
            val progress = scrollState.value.toFloat() / scrollState.maxValue.toFloat()
            viewModel.updateReadingProgress(progress, scrollState.value)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (article != null) {
                        IconButton(onClick = {
                            onStartTts(
                                article.id,
                                article.title,
                                article.publisher ?: "Web Article",
                                article.plainText
                            )
                        }) {
                            Icon(Icons.Default.Headphones, contentDescription = "Listen with Text to Speech")
                        }

                        IconButton(onClick = { viewModel.toggleFavorite() }) {
                            Icon(
                                imageVector = if (article.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (article.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            )
                        }

                        IconButton(onClick = { showFontMenu = true }) {
                            Icon(Icons.Default.FormatSize, contentDescription = "Appearance Settings")
                        }

                        DropdownMenu(
                            expanded = showFontMenu,
                            onDismissRequest = { showFontMenu = false }
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Font Size: ${state.preferences.fontSizeSp} sp", style = MaterialTheme.typography.titleSmall)
                                Slider(
                                    value = state.preferences.fontSizeSp.toFloat(),
                                    onValueChange = { viewModel.updateFontSize(it.toInt()) },
                                    valueRange = 12f..32f
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Line Spacing", style = MaterialTheme.typography.titleSmall)
                                Row {
                                    listOf(1.2f, 1.4f, 1.6f, 1.8f).forEach { spacing ->
                                        IconButton(onClick = { viewModel.updateLineSpacing(spacing) }) {
                                            Text("${spacing}x", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (state.isLoading || article == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val fontFamily = when (state.preferences.fontFamily) {
                "SERIF" -> FontFamily.Serif
                "MONOSPACE" -> FontFamily.Monospace
                "SANS_SERIF" -> FontFamily.SansSerif
                else -> FontFamily.Default
            }

            val fontSize = state.preferences.fontSizeSp.sp
            val lineSpacing = (state.preferences.fontSizeSp * state.preferences.lineSpacingMultiplier).sp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                // Publisher & Date
                Text(
                    text = buildString {
                        append(article.publisher ?: "Web Article")
                        if (!article.author.isNullOrBlank()) append(" • ").append(article.author)
                        if (!article.publishedDate.isNullOrBlank()) append(" • ").append(article.publishedDate)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Title
                Text(
                    text = article.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    fontFamily = fontFamily
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${article.estimatedReadingTimeMinutes} min read",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Featured Image
                val imageModel = article.featuredImageLocalPath?.let { File(it) } ?: article.featuredImageUrl
                if (imageModel != null) {
                    AsyncImage(
                        model = imageModel,
                        contentDescription = "Featured image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Article Main Text (Selectable for copying & highlighting)
                SelectionContainer {
                    Text(
                        text = article.plainText,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = fontSize,
                            lineHeight = lineSpacing,
                            fontFamily = fontFamily
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
