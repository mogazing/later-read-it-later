package com.example.pocketreborn.data.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

class ImageDownloader(
    private val context: Context,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {

    suspend fun downloadImage(articleId: String, imageUrl: String): Result<String> = withContext(Dispatchers.IO) {
        if (!NetworkSecurityUtils.isSafeUrl(imageUrl)) {
            return@withContext Result.failure(IllegalArgumentException("Unsafe image URL destination."))
        }

        val imagesDir = File(context.filesDir, "article_images/$articleId")
        if (!imagesDir.exists()) {
            imagesDir.mkdirs()
        }

        val tempFile = File(imagesDir, "temp_${UUID.randomUUID()}.tmp")
        val extension = getExtensionFromUrl(imageUrl)
        val finalFile = File(imagesDir, "img_${UUID.randomUUID().toString().take(8)}.$extension")

        val request = Request.Builder()
            .url(imageUrl)
            .header("User-Agent", "LaterApp/1.0 ImageDownloader")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP ${response.code} downloading image."))
                }

                val body = response.body ?: return@withContext Result.failure(Exception("Empty image body."))

                body.byteStream().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (tempFile.renameTo(finalFile)) {
                    Result.success(finalFile.absolutePath)
                } else {
                    tempFile.copyTo(finalFile, overwrite = true)
                    tempFile.delete()
                    Result.success(finalFile.absolutePath)
                }
            }
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            Result.failure(e)
        }
    }

    private fun getExtensionFromUrl(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.endsWith(".png") -> "png"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "jpg"
            lower.endsWith(".webp") -> "webp"
            lower.endsWith(".gif") -> "gif"
            lower.endsWith(".svg") -> "svg"
            else -> "jpg"
        }
    }
}
