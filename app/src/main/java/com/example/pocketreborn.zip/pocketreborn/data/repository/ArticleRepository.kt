package com.example.pocketreborn.data.repository

import android.content.Context
import com.example.pocketreborn.data.local.dao.ArticleDao
import com.example.pocketreborn.data.local.entity.ArticleEntity
import com.example.pocketreborn.data.local.entity.ArticleImageEntity
import com.example.pocketreborn.data.network.ArticleExtractor
import com.example.pocketreborn.data.network.ImageDownloader
import com.example.pocketreborn.data.network.NetworkSecurityUtils
import com.example.pocketreborn.data.network.UrlResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class SaveResult {
    data class Success(val articleId: String, val isPartial: Boolean) : SaveResult()
    data class ExistingDuplicate(val articleId: String) : SaveResult()
    data class Error(val message: String, val articleId: String? = null) : SaveResult()
}

class ArticleRepository(
    private val articleDao: ArticleDao,
    private val urlResolver: UrlResolver = UrlResolver(),
    private val context: Context
) {
    private val imageDownloader = ImageDownloader(context)

    fun getAllActiveArticles(): Flow<List<ArticleEntity>> = articleDao.getAllActiveArticles()

    fun getArchivedArticles(): Flow<List<ArticleEntity>> = articleDao.getArchivedArticles()

    fun getFavoriteArticles(): Flow<List<ArticleEntity>> = articleDao.getFavoriteArticles()

    fun getArticlesByFolder(folderId: String): Flow<List<ArticleEntity>> = articleDao.getArticlesByFolder(folderId)

    fun getArticleByIdFlow(id: String): Flow<ArticleEntity?> = articleDao.getArticleByIdFlow(id)

    suspend fun getArticleById(id: String): ArticleEntity? = articleDao.getArticleById(id)

    fun searchArticles(query: String): Flow<List<ArticleEntity>> = articleDao.searchArticles(query)

    suspend fun saveArticleFromUrl(rawUrl: String): SaveResult = withContext(Dispatchers.IO) {
        val extractedUrl = NetworkSecurityUtils.extractUrlFromSharedText(rawUrl) ?: rawUrl.trim()
        val normalizedUrl = NetworkSecurityUtils.normalizeUrl(extractedUrl)

        if (!NetworkSecurityUtils.isSafeUrl(normalizedUrl)) {
            return@withContext SaveResult.Error("Invalid or restricted URL: $rawUrl")
        }

        // Duplicate Check
        val existing = articleDao.getArticleByUrl(normalizedUrl)
        if (existing != null) {
            return@withContext SaveResult.ExistingDuplicate(existing.id)
        }

        val articleId = UUID.randomUUID().toString()
        val initialEntity = ArticleEntity(
            id = articleId,
            originalUrl = normalizedUrl,
            title = normalizedUrl,
            content = "",
            plainText = "",
            downloadState = "RESOLVING",
            dateSaved = System.currentTimeMillis()
        )
        articleDao.insertArticle(initialEntity)

        // Step 1: Fetch Page
        articleDao.updateDownloadState(articleId, "FETCHING")
        val pageResult = urlResolver.resolveAndFetch(normalizedUrl)
        if (pageResult.isFailure) {
            val err = pageResult.exceptionOrNull()?.message ?: "Failed to retrieve web page."
            // Save as bookmark
            articleDao.updateDownloadState(articleId, "BOOKMARK_ONLY", err)
            return@withContext SaveResult.Error("Page fetch failed: $err. Saved as bookmark.", articleId)
        }

        val resolved = pageResult.getOrThrow()

        // Step 2: Extract Article Content
        articleDao.updateDownloadState(articleId, "EXTRACTING")
        val extracted = try {
            ArticleExtractor.extract(resolved.htmlContent, resolved.finalUrl)
        } catch (e: Exception) {
            val err = "Extraction failed: ${e.message}"
            articleDao.updateDownloadState(articleId, "BOOKMARK_ONLY", err)
            return@withContext SaveResult.Error(err, articleId)
        }

        if (extracted.plainText.isBlank()) {
            articleDao.updateDownloadState(articleId, "BOOKMARK_ONLY", "No readable article content found.")
            return@withContext SaveResult.Error("No readable article text found on page.", articleId)
        }

        // Step 3: Save Extracted Content
        val updatedEntity = initialEntity.copy(
            canonicalUrl = extracted.canonicalUrl,
            title = extracted.title,
            author = extracted.author,
            publisher = extracted.publisher,
            publishedDate = extracted.publishedDate,
            content = extracted.contentHtml,
            plainText = extracted.plainText,
            excerpt = extracted.excerpt,
            featuredImageUrl = extracted.featuredImageUrl,
            estimatedReadingTimeMinutes = extracted.estimatedReadingTimeMinutes,
            downloadState = "DOWNLOADING_IMAGES",
            lastUpdated = System.currentTimeMillis()
        )
        articleDao.insertArticle(updatedEntity)

        // Step 4: Download Images
        var featuredLocalPath: String? = null
        if (!extracted.featuredImageUrl.isNullOrBlank()) {
            val res = imageDownloader.downloadImage(articleId, extracted.featuredImageUrl)
            if (res.isSuccess) {
                featuredLocalPath = res.getOrNull()
            }
        }

        var imageFailures = 0
        val imageEntities = mutableListOf<ArticleImageEntity>()

        for (img in extracted.images.take(15)) { // limit to top 15 images
            val res = imageDownloader.downloadImage(articleId, img.url)
            val localPath = res.getOrNull()
            if (localPath == null) {
                imageFailures++
            }
            imageEntities.add(
                ArticleImageEntity(
                    id = UUID.randomUUID().toString(),
                    articleId = articleId,
                    remoteUrl = img.url,
                    localPath = localPath,
                    caption = img.caption,
                    isDownloaded = localPath != null
                )
            )
        }

        if (imageEntities.isNotEmpty()) {
            articleDao.insertImages(imageEntities)
        }

        val finalState = if (imageFailures > 0) "PARTIALLY_SAVED" else "SAVED_OFFLINE"
        articleDao.insertArticle(
            updatedEntity.copy(
                featuredImageLocalPath = featuredLocalPath,
                downloadState = finalState
            )
        )

        SaveResult.Success(articleId = articleId, isPartial = imageFailures > 0)
    }

    suspend fun updateReadingProgress(id: String, progress: Float, position: Int) {
        articleDao.updateReadingProgress(id, progress, position)
        if (progress >= 0.95f) {
            articleDao.updateReadStatus(id, true)
        }
    }

    suspend fun markAsRead(id: String, isRead: Boolean) {
        articleDao.updateReadStatus(id, isRead)
    }

    suspend fun toggleFavorite(id: String) {
        val current = articleDao.getArticleById(id) ?: return
        articleDao.updateFavoriteStatus(id, !current.isFavorite)
    }

    suspend fun toggleArchive(id: String) {
        val current = articleDao.getArticleById(id) ?: return
        articleDao.updateArchiveStatus(id, !current.isArchived)
    }

    suspend fun assignToFolder(id: String, folderId: String?) {
        articleDao.updateArticleFolder(id, folderId)
    }

    suspend fun updateTtsPosition(id: String, positionMs: Long, paragraphIndex: Int) {
        articleDao.updateTtsPosition(id, positionMs, paragraphIndex)
    }

    suspend fun deleteArticle(id: String) {
        articleDao.deleteArticleById(id)
    }
}
