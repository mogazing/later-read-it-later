package com.example.pocketreborn

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.pocketreborn.data.local.AppDatabase
import com.example.pocketreborn.data.network.NetworkSecurityUtils
import com.example.pocketreborn.data.repository.ArticleRepository
import com.example.pocketreborn.data.repository.FolderRepository
import com.example.pocketreborn.data.repository.HighlightRepository
import com.example.pocketreborn.data.repository.UserPreferencesRepository
import com.example.pocketreborn.navigation.Screen
import com.example.pocketreborn.service.TtsPlaybackState
import com.example.pocketreborn.service.TtsService
import com.example.pocketreborn.ui.components.BottomNavBar
import com.example.pocketreborn.ui.components.TtsBottomBarPlayer
import com.example.pocketreborn.ui.folders.FoldersScreen
import com.example.pocketreborn.ui.folders.FoldersViewModel
import com.example.pocketreborn.ui.highlights.HighlightsScreen
import com.example.pocketreborn.ui.highlights.HighlightsViewModel
import com.example.pocketreborn.ui.library.LibraryScreen
import com.example.pocketreborn.ui.library.LibraryViewModel
import com.example.pocketreborn.ui.reader.ReaderScreen
import com.example.pocketreborn.ui.reader.ReaderViewModel
import com.example.pocketreborn.ui.search.SearchScreen
import com.example.pocketreborn.ui.search.SearchViewModel
import com.example.pocketreborn.ui.settings.SettingsScreen
import com.example.pocketreborn.ui.settings.SettingsViewModel
import com.example.pocketreborn.ui.theme.PocketRebornTheme

class MainActivity : ComponentActivity() {

    private lateinit var articleRepository: ArticleRepository
    private lateinit var folderRepository: FolderRepository
    private lateinit var highlightRepository: HighlightRepository
    private lateinit var userPreferencesRepository: UserPreferencesRepository

    private lateinit var libraryViewModel: LibraryViewModel
    private lateinit var readerViewModel: ReaderViewModel
    private lateinit var searchViewModel: SearchViewModel
    private lateinit var foldersViewModel: FoldersViewModel
    private lateinit var highlightsViewModel: HighlightsViewModel
    private lateinit var settingsViewModel: SettingsViewModel

    private var ttsService: TtsService? = null
    private var isTtsBound = false

    private val pendingSharedUrl = mutableStateOf<String?>(null)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as TtsService.LocalBinder
            ttsService = binder.getService()
            isTtsBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            ttsService = null
            isTtsBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getInstance(applicationContext)
        articleRepository = ArticleRepository(db.articleDao(), context = applicationContext)
        folderRepository = FolderRepository(db.folderDao())
        highlightRepository = HighlightRepository(db.highlightDao())
        userPreferencesRepository = UserPreferencesRepository(applicationContext)

        libraryViewModel = LibraryViewModel(articleRepository)
        readerViewModel = ReaderViewModel(articleRepository, highlightRepository, userPreferencesRepository)
        searchViewModel = SearchViewModel(articleRepository)
        foldersViewModel = FoldersViewModel(folderRepository, articleRepository)
        highlightsViewModel = HighlightsViewModel(highlightRepository)
        settingsViewModel = SettingsViewModel(userPreferencesRepository)

        handleIncomingIntent(intent)

        // Bind TTS Service
        val serviceIntent = Intent(this, TtsService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)

        setContent {
            val prefs by userPreferencesRepository.userPreferencesFlow.collectAsState(initial = com.example.pocketreborn.data.repository.UserPreferences())

            val darkTheme = when (prefs.themeMode) {
                "LIGHT" -> false
                "DARK" -> true
                else -> isSystemInDarkTheme()
            }

            PocketRebornTheme(darkTheme = darkTheme) {
                MainAppContent(
                    libraryViewModel = libraryViewModel,
                    readerViewModel = readerViewModel,
                    searchViewModel = searchViewModel,
                    foldersViewModel = foldersViewModel,
                    highlightsViewModel = highlightsViewModel,
                    settingsViewModel = settingsViewModel,
                    ttsService = ttsService,
                    pendingUrl = pendingSharedUrl.value,
                    onUrlHandled = { pendingSharedUrl.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                if ("text/plain" == intent.type) {
                    val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                    if (!sharedText.isNullOrBlank()) {
                        val extractedUrl = NetworkSecurityUtils.extractUrlFromSharedText(sharedText)
                        if (extractedUrl != null) {
                            pendingSharedUrl.value = extractedUrl
                        }
                    }
                }
            }
            Intent.ACTION_VIEW -> {
                val dataUrl = intent.dataString
                if (!dataUrl.isNullOrBlank() && NetworkSecurityUtils.isSafeUrl(dataUrl)) {
                    pendingSharedUrl.value = dataUrl
                }
            }
        }
    }

    override fun onDestroy() {
        if (isTtsBound) {
            unbindService(serviceConnection)
            isTtsBound = false
        }
        super.onDestroy()
    }
}

@Composable
fun MainAppContent(
    libraryViewModel: LibraryViewModel,
    readerViewModel: ReaderViewModel,
    searchViewModel: SearchViewModel,
    foldersViewModel: FoldersViewModel,
    highlightsViewModel: HighlightsViewModel,
    settingsViewModel: SettingsViewModel,
    ttsService: TtsService?,
    pendingUrl: String?,
    onUrlHandled: () -> Unit
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Handle shared URL automatically
    DisposableEffect(pendingUrl) {
        if (!pendingUrl.isNullOrBlank()) {
            libraryViewModel.saveUrl(pendingUrl)
            onUrlHandled()
        }
        onDispose { }
    }

    val ttsState = ttsService?.playbackState?.collectAsState()?.value ?: TtsPlaybackState()

    val showBottomBar = currentRoute in listOf(
        Screen.Library.route,
        Screen.Search.route,
        Screen.Folders.route,
        Screen.Highlights.route,
        Screen.Settings.route
    )

    Scaffold(
        bottomBar = {
            Column {
                if (ttsState.articleId != null) {
                    TtsBottomBarPlayer(
                        state = ttsState,
                        onPlayPause = {
                            if (ttsState.isPlaying) ttsService?.pausePlayback() else ttsService?.resumePlayback()
                        },
                        onSkipForward = { ttsService?.skipForward() },
                        onSkipBackward = { ttsService?.skipBackward() },
                        onSetSpeed = { ttsService?.setSpeed(it) },
                        onClose = { ttsService?.stopPlayback() },
                        onOpenReader = { articleId ->
                            navController.navigate(Screen.Reader.createRoute(articleId))
                        }
                    )
                }

                if (showBottomBar) {
                    BottomNavBar(
                        currentRoute = currentRoute,
                        onNavigate = { screen ->
                            navController.navigate(screen.route) {
                                popUpTo(Screen.Library.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Library.route
            ) {
                composable(Screen.Library.route) {
                    LibraryScreen(
                        viewModel = libraryViewModel,
                        onOpenArticle = { articleId ->
                            navController.navigate(Screen.Reader.createRoute(articleId))
                        }
                    )
                }

                composable(
                    route = Screen.Reader.route,
                    arguments = listOf(navArgument("articleId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val articleId = backStackEntry.arguments?.getString("articleId") ?: ""
                    ReaderScreen(
                        articleId = articleId,
                        viewModel = readerViewModel,
                        onBack = { navController.popBackStack() },
                        onStartTts = { id, title, pub, text ->
                            ttsService?.playArticle(id, title, pub, text)
                        }
                    )
                }

                composable(Screen.Search.route) {
                    SearchScreen(
                        viewModel = searchViewModel,
                        onOpenArticle = { articleId ->
                            navController.navigate(Screen.Reader.createRoute(articleId))
                        }
                    )
                }

                composable(Screen.Folders.route) {
                    FoldersScreen(
                        viewModel = foldersViewModel,
                        onOpenArticle = { articleId ->
                            navController.navigate(Screen.Reader.createRoute(articleId))
                        }
                    )
                }

                composable(Screen.Highlights.route) {
                    HighlightsScreen(
                        viewModel = highlightsViewModel,
                        onOpenArticle = { articleId ->
                            navController.navigate(Screen.Reader.createRoute(articleId))
                        }
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(viewModel = settingsViewModel)
                }
            }
        }
    }
}
