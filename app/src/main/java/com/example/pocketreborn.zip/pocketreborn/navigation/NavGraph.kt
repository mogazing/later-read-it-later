package com.example.pocketreborn.navigation

sealed class Screen(val route: String) {
    object Library : Screen("library")
    object Reader : Screen("reader/{articleId}") {
        fun createRoute(articleId: String) = "reader/$articleId"
    }
    object Search : Screen("search")
    object Folders : Screen("folders")
    object Highlights : Screen("highlights")
    object Settings : Screen("settings")
}
