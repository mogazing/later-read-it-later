package com.example.pocketreborn.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pocketreborn.data.local.entity.ArticleEntity
import com.example.pocketreborn.data.repository.ArticleRepository
import com.example.pocketreborn.data.repository.SaveResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LibraryFilter {
    ALL, FAVORITES, ARCHIVED, UNREAD
}

enum class SortOrder {
    NEWEST, OLDEST, READING_TIME
}

data class LibraryUiState(
    val articles: List<ArticleEntity> = emptyList(),
    val filter: LibraryFilter = LibraryFilter.ALL,
    val sortOrder: SortOrder = SortOrder.NEWEST,
    val isSaving: Boolean = false,
    val saveErrorMessage: String? = null,
    val saveSuccessMessage: String? = null
)

class LibraryViewModel(
    private val repository: ArticleRepository
) : ViewModel() {

    private val _filter = MutableStateFlow(LibraryFilter.ALL)
    private val _sortOrder = MutableStateFlow(SortOrder.NEWEST)
    private val _isSaving = MutableStateFlow(false)
    private val _saveError = MutableStateFlow<String?>(null)
    private val _saveSuccess = MutableStateFlow<String?>(null)

    val uiState: StateFlow<LibraryUiState> = combine(
        combine(_filter, _sortOrder, _isSaving, _saveError, _saveSuccess) { f, s, saving, err, succ ->
            Triple(f, s, Triple(saving, err, succ))
        },
        repository.getAllActiveArticles(),
        repository.getFavoriteArticles(),
        repository.getArchivedArticles()
    ) { params, active, favorites, archived ->
        val filter = params.first
        val sort = params.second
        val saving = params.third.first
        val error = params.third.second
        val success = params.third.third

        val filteredList = when (filter) {
            LibraryFilter.ALL -> active
            LibraryFilter.FAVORITES -> favorites
            LibraryFilter.ARCHIVED -> archived
            LibraryFilter.UNREAD -> active.filter { !it.isRead }
        }

        val sortedList = when (sort) {
            SortOrder.NEWEST -> filteredList.sortedByDescending { it.dateSaved }
            SortOrder.OLDEST -> filteredList.sortedBy { it.dateSaved }
            SortOrder.READING_TIME -> filteredList.sortedBy { it.estimatedReadingTimeMinutes }
        }

        LibraryUiState(
            articles = sortedList,
            filter = filter,
            sortOrder = sort,
            isSaving = saving,
            saveErrorMessage = error,
            saveSuccessMessage = success
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState()
    )

    fun setFilter(filter: LibraryFilter) {
        _filter.value = filter
    }

    fun setSortOrder(sortOrder: SortOrder) {
        _sortOrder.value = sortOrder
    }

    fun saveUrl(url: String) {
        viewModelScope.launch {
            _isSaving.value = true
            _saveError.value = null
            _saveSuccess.value = null

            when (val result = repository.saveArticleFromUrl(url)) {
                is SaveResult.Success -> {
                    _isSaving.value = false
                    _saveSuccess.value = if (result.isPartial) {
                        "Article saved offline (some images unavailable)."
                    } else {
                        "Article saved for offline reading!"
                    }
                }
                is SaveResult.ExistingDuplicate -> {
                    _isSaving.value = false
                    _saveSuccess.value = "Article is already in your library."
                }
                is SaveResult.Error -> {
                    _isSaving.value = false
                    _saveError.value = result.message
                }
            }
        }
    }

    fun clearMessages() {
        _saveError.value = null
        _saveSuccess.value = null
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch { repository.toggleFavorite(id) }
    }

    fun toggleArchive(id: String) {
        viewModelScope.launch { repository.toggleArchive(id) }
    }

    fun toggleRead(id: String) {
        viewModelScope.launch {
            val article = repository.getArticleById(id) ?: return@launch
            repository.markAsRead(id, !article.isRead)
        }
    }

    fun assignFolder(id: String, folderId: String?) {
        viewModelScope.launch { repository.assignToFolder(id, folderId) }
    }

    fun deleteArticle(id: String) {
        viewModelScope.launch { repository.deleteArticle(id) }
    }
}
